﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    
    /// Interaction logic for MainWindow.xaml
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ShowHidePlaceholder();
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            ShowHidePlaceholder();
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            ShowHidePlaceholder();
        }

        private void ShowHidePlaceholder()
        {
            placeholder_firstName.Visibility = string.IsNullOrEmpty(firstName.Text) ? Visibility.Visible : Visibility.Collapsed;
            placeholder_lastName.Visibility = string.IsNullOrEmpty(lastName.Text) ? Visibility.Visible : Visibility.Collapsed;
            placeholder_phoneNumber.Visibility = string.IsNullOrEmpty(phoneNumber.Text) ? Visibility.Visible : Visibility.Collapsed;
            placeholder_streetAddress.Visibility = string.IsNullOrEmpty(streetAddress.Text) ? Visibility.Visible : Visibility.Collapsed;
            placeholder_city.Visibility = string.IsNullOrEmpty(city.Text) ? Visibility.Visible : Visibility.Collapsed;
            placeholder_postalZipCodew.Visibility = string.IsNullOrEmpty(postalZipCodew.Text) ? Visibility.Visible : Visibility.Collapsed;
        }

    }
}